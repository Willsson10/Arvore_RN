/*
    Módulo onde são chamadas todas as bilbitoecas utilizadas durante
    o projeto.
*/

#ifndef _HEADERS_H
#define _HEADERS_H

#include "arvore.h"
#include "dot.h"

#endif